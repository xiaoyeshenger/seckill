package top.javatool.canal.client.enums;

/**
 * @author yang peng
 * @date 2019/4/1915:20
 */
public enum TableNameEnum {

    ALL;


    @Override
    public String

    toString() {
        return super.toString();
    }
}
