package top.javatool.canal.client.client;

/**
 * @author yang peng
 * @date 2019/3/2618:25
 */
public interface CanalClient {


    void start();



    void stop();



    void process();
}
