package top.javatool.canal.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CanalExampleApplication {


    public static void main(String[] args) {

        SpringApplication.run(CanalExampleApplication.class, args);
    }



}
